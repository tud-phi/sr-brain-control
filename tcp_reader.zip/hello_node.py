import rclpy
from std_msgs.msg import String
from tcp_reader.msg import HelloROS2

def callback(msg):
    print("Received message: ", msg.message)

def main(args=None):
    rclpy.init(args=args)
    node = rclpy.create_node('hello_node')

    # Subscribe to the hello_topic
    sub = node.create_subscription(HelloROS2, 'hello_topic', callback, 10)

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
