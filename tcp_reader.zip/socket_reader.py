#!/usr/bin/env python3

import socket
import rclpy
from std_msgs.msg import String  # Import the appropriate message type
from tcp_reader.msg import MyMessage  # Import your custom message type

def main():
    rclpy.init()

    node = rclpy.create_node('socket_reader')
    publisher = node.create_publisher(MyMessage, 'socket_data', 10)

    host = 'localhost'
    port = 5678

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((host, port))
        s.listen()

        print(f"Listening on {host}:{port}")
        conn, addr = s.accept()
        print(f"Connected by {addr}")

        while rclpy.ok():
            data = conn.recv(1024).decode('utf-8')
            if not data:
                break

            msg = MyMessage()  # Create an instance of your custom message
            msg.data = data    # Assign received data to the message field

            publisher.publish(msg)
            node.get_logger().info(f"Published: {data}")

        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
